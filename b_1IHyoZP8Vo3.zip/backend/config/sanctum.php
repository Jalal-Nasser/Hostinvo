<?php

use Laravel\Sanctum\Sanctum;

$extractHostWithPort = static function (?string $value): ?string {
    if (! is_string($value) || trim($value) === '') {
        return null;
    }

    $normalized = preg_match('#^https?://#', $value) ? $value : "https://{$value}";
    $parts = parse_url($normalized);

    if (! is_array($parts) || ! isset($parts['host'])) {
        return trim($value, '/');
    }

    return isset($parts['port'])
        ? "{$parts['host']}:{$parts['port']}"
        : $parts['host'];
};

$defaultStatefulDomains = array_values(array_unique(array_filter([
    'localhost',
    'localhost:3000',
    'localhost:8080',
    '127.0.0.1',
    '127.0.0.1:3000',
    '127.0.0.1:8080',
    '::1',
    $extractHostWithPort(env('MARKETING_URL')),
    $extractHostWithPort(env('PORTAL_URL')),
    $extractHostWithPort(env('APP_URL')),
    $extractHostWithPort(Sanctum::currentApplicationUrlWithPort()),
])));

return [

    /*
    |--------------------------------------------------------------------------
    | Stateful Domains
    |--------------------------------------------------------------------------
    |
    | Requests from the following domains / hosts will receive stateful API
    | authentication cookies. Typically, these should include your local
    | and production domains which access your API via a frontend SPA.
    |
    */

    'stateful' => explode(
        ',',
        env('SANCTUM_STATEFUL_DOMAINS', implode(',', $defaultStatefulDomains)),
    ),

    /*
    |--------------------------------------------------------------------------
    | Sanctum Guards
    |--------------------------------------------------------------------------
    |
    | This array contains the authentication guards that will be checked when
    | Sanctum is trying to authenticate a request. If none of these guards
    | are able to authenticate the request, Sanctum will use the bearer
    | token that's present on an incoming request for authentication.
    |
    */

    'guard' => ['web'],

    /*
    |--------------------------------------------------------------------------
    | Expiration Minutes
    |--------------------------------------------------------------------------
    |
    | This value controls the number of minutes until an issued token will be
    | considered expired. This will override any values set in the token's
    | "expires_at" attribute, but first-party sessions are not affected.
    |
    */

    'expiration' => null,

    /*
    |--------------------------------------------------------------------------
    | Token Prefix
    |--------------------------------------------------------------------------
    |
    | Sanctum can prefix new tokens in order to take advantage of numerous
    | security scanning initiatives maintained by open source platforms
    | that notify developers if they commit tokens into repositories.
    |
    | See: https://docs.github.com/en/code-security/secret-scanning/about-secret-scanning
    |
    */

    'token_prefix' => env('SANCTUM_TOKEN_PREFIX', ''),

    /*
    |--------------------------------------------------------------------------
    | Sanctum Middleware
    |--------------------------------------------------------------------------
    |
    | When authenticating your first-party SPA with Sanctum you may need to
    | customize some of the middleware Sanctum uses while processing the
    | request. You may change the middleware listed below as required.
    |
    */

    'middleware' => [
        'authenticate_session' => Laravel\Sanctum\Http\Middleware\AuthenticateSession::class,
        'encrypt_cookies' => Illuminate\Cookie\Middleware\EncryptCookies::class,
        'validate_csrf_token' => Illuminate\Foundation\Http\Middleware\ValidateCsrfToken::class,
    ],

];
