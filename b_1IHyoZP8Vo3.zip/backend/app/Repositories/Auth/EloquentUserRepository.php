<?php

namespace App\Repositories\Auth;

use App\Contracts\Repositories\Auth\UserRepositoryInterface;
use App\Models\User;
use App\Models\Scopes\TenantScope;

class EloquentUserRepository implements UserRepositoryInterface
{
    public function findByEmail(string $email): ?User
    {
        return User::query()
            ->withoutGlobalScope(TenantScope::class)
            ->with(['tenant', 'roles.permissions'])
            ->where('email', $email)
            ->first();
    }

    public function findByEmailForTenant(string $email, string $tenantId): ?User
    {
        return User::query()
            ->with(['tenant', 'roles.permissions'])
            ->where('tenant_id', $tenantId)
            ->where('email', $email)
            ->first();
    }

    public function findById(string $id): ?User
    {
        return User::query()
            ->withoutGlobalScope(TenantScope::class)
            ->with(['tenant', 'roles.permissions'])
            ->find($id);
    }

    public function save(User $user): bool
    {
        return $user->save();
    }
}
