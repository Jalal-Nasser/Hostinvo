<?php

namespace App\Http\Requests\Support;

use App\Http\Requests\Concerns\SanitizesInputContent;
use App\Models\Ticket;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreTicketReplyRequest extends FormRequest
{
    use SanitizesInputContent;

    public function authorize(): bool
    {
        $ticket = $this->route('ticket');

        return $ticket instanceof Ticket && $this->user()->can('reply', $ticket);
    }

    protected function prepareForValidation(): void
    {
        $this->sanitizePlainTextFields(['message']);
    }

    public function rules(): array
    {
        /** @var Ticket $ticket */
        $ticket = $this->route('ticket');
        $tenantId = $this->user()?->tenant_id ?? $ticket->tenant_id;

        return [
            'client_contact_id' => [
                'nullable',
                'uuid',
                Rule::exists('client_contacts', 'id')->where(fn ($query) => $query->where('tenant_id', $tenantId)),
            ],
            'assigned_to_user_id' => [
                'nullable',
                'uuid',
                Rule::exists('users', 'id')->where(fn ($query) => $query->where('tenant_id', $tenantId)),
            ],
            'status_id' => [
                'nullable',
                'integer',
                Rule::exists('ticket_statuses', 'id')->where(fn ($query) => $query->where('tenant_id', $tenantId)),
            ],
            'is_internal' => ['nullable', 'boolean'],
            'message' => ['required', 'string'],
            'metadata' => ['nullable', 'array'],
        ];
    }
}
